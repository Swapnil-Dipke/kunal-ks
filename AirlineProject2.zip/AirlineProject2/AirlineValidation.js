// alert('javascript1 is called');

function validateLoginForm() {
    validateUsername();
    validatePassword();
    return false;
}

function validateRegistrationForm() {
    validateUsername();
    validatePassword();
    validateConfirmPassword();
}

function validateUsername() {
    let username = document.getElementById("uname").value;
    if(username == "" ) {
        //alert('username cannot be blank');
        console.log('USERNAME CANNOT BE BLANK');
        document.getElementById("userSpan").innerHTML='Username cannot be blank';
        return false;
    }
    if(username.length < 8 ) {
        document.getElementById("userSpan").innerHTML='Username should be more than 8 letters';
        return false;
    }
}
function validatePassword() {
    let password = document.getElementById("upass").value;
    console.log(password);
    if(password == "" ) {
        // alert("password cannot be blank");
        console.log('PASSWORD CANNOT BE BLANK');
        document.getElementById("passSpan").innerHTML='Password cannot be blank';
        return false;
    }
    console.log(password.length);
    if(password.length < 8 ) {
        document.getElementById("passSpan").innerHTML='Password should be more than 8 letters';
        return false;
    }
    else {
        document.getElementById("passSpan").innerHTML='';
    }

}
function validateConfirmPassword() {
    let password = document.getElementById("upass").value;
    let password2 = document.getElementById("upass2").value;
    if(password == "" ) {
        // alert("password cannot be blank");
        console.log('PASSWORD CANNOT BE BLANK');
        document.getElementById("passSpan").innerHTML='Password cannot be blank';
        return false;
    }
    if(password2 == "" ) {
        // alert("password cannot be blank");
        console.log('PASSWORD CANNOT BE BLANK');
        document.getElementById("passSpan2").innerHTML='Password cannot be blank';
        return false;
    }
    if(password.length < 8 ) {
        document.getElementById("passSpan").innerHTML='Password should be more than 8 letters';
        return false;
    }

    if(password2.length < 8 ) {
        document.getElementById("passSpan2").innerHTML='Password should be more than 8 letters';
        return false;
    }

    if(password != password2) {
        document.getElementById("passSpan2").innerHTML='Passwords not matching';
        return false;
    } else {
        document.getElementById("passSpan").innerHTML='';
        document.getElementById("passSpan2").innerHTML='';
    }
}

/*
function validateMyForm() {
    //alert('Validating my login form');
    let username = document.getElementById("uname").value;
    let password = document.getElementById("upass").value;


    //alert(username+':'+password);
    if(username == "" ) {
        //alert('username cannot be blank');
        console.log('USERNAME CANNOT BE BLANK');
        document.getElementById("userSpan").innerHTML='Username cannot be blank';
        return false;
    }

    if(username.length < 8 ) {
        document.getElementById("userSpan").innerHTML='Username should be more than 8 letters';
        return false;
    }

    if(password == "" ) {
        // alert("password cannot be blank");
        console.log('PASSWORD CANNOT BE BLANK');
        document.getElementById("passSpan").innerHTML='Password cannot be blank';
        return false;
    }

    if(password.length < 8 ) {
        document.getElementById("passSpan").innerHTML='Password should be more than 8 letters';
        return false;
    }

    let password2 = document.getElementById("upass2").value;
    if(password2.length < 8 ) {
        document.getElementById("passSpan2").innerHTML='Password should be more than 8 letters';
        return false;
    }


    if(password != password2) {
        document.getElementById("passSpan2").innerHTML='Passwords not matching';
        return false;
    } else {
        document.getElementById("passSpan").innerHTML='';
        document.getElementById("passSpan2").innerHTML='';
    }




    return true; //true is the proof that all is OK
}
*/

function userErrorMessage() {
    let username = document.getElementById('uname').value;
    console.log(username);

    if(username.length>0) {
        document.getElementById("userSpan").innerHTML='';
    }
}
function passwordErrorMessage() {
    let password = document.getElementById('upass').value;
    console.log(password);

    if(password.length>0) {
        document.getElementById("passSpan").innerHTML='';
    }
}