package com.example.demo;

import java.time.LocalDate;




import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Passenger;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.AdminRepositoryImpl;
import com.example.demo.layer3.PassengerRepositoryImpl;


@SpringBootTest
class AirlineReservationApplicationTests {


	

	/*
	//----------- one to one for transaction ---------------------------
	
	@Autowired
	TransactionnRepositoryImpl transactionRepository;
	
	
	@Test
	void insertTransactionTest()
	{
		Transaction tran=new Transaction();
		tran.setTrannsactionId(3);
		tran.setTransactionType("Online");
		tran.setTransactionAmount(12000.0f);
		tran.setTransactionMode("succ");
		tran.setTransactionStatus("active");
//		transactionRepo.insertTransaction("Tran");
		transactionRepository.insertTransaction(tran);
		

//		Transaction tran2=new Transaction();
//		tran2.setTrannsactionId(5);
//		tran2.setTransactionType("Online");
//		tran2.setTransactionAmount(100.0f);
//		tran2.setTransactionStatus("active");
////		transactionRepo.insertTransaction("Tran");
//		transactionRepository.insertTransaction("tran");
//		
	}
	
	
	
	@Autowired
	InsertEmploymentImpl emp = new InsertEmploymentImpl();		//Employment
	@Test
	void insertEmployment(){
		Employment e = new Employment();
		Customer c = cust.selectCustomer(44l);
		e.setCustomer(c);
		e.setEmployerName("Abc Company");
		e.setIncomeFromOtherSources(10000d);
		e.setNetMonthlyIncome(25000d);
		e.setOrganizationType("Private");
		e.setRetirementAge("60");
		e.setTypeOfEmployement("IT");
		e.setWorkExperience(10);
	    emp.insertEmployment(e);
	
	}
	*/
	
	@Autowired
	PassengerRepositoryImpl passengerRepository;
	

	
	@Test
	public void insertPassengerTest()
	{
		Passenger pass=new Passenger();
		pass.setPassengerId(3);
		pass.setFirstName("Arpit");
		pass.setLastName("Bawane");
		pass.setGender('M');
		
		passengerRepository.insertPassenger(pass);
		
	}
	
	
	 @Autowired
	    AdminRepositoryImpl  adminRepositoryImpl;
	  
	    @Test
	    public void insertAdminTest() {
	        Admin Akt=new Admin();
	        Akt.setAdminId(13);
	        Akt.setAdminPassward("ddsdfsdnn34");
	     // adminRepoImpl.insertAdmin(Akt);
	        adminRepositoryImpl.insertAdmin(Akt);
	    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//  -------------------  ONE TO MANNY  ----------------------
	
	
	/*
	@Autowired
	CustomerReposioryImpl cusRepo;

	@Autowired
	DocumentRepositoryImpl DocRepo;

	@Test
	void insertDocument()
	{
	Customer customer =cusRepo.selectCustomer(33);
	Document doc=new Document();
	{
	doc.setPanCard("Ram1234cu");
	doc.setVoterId("hjkkfj68574");
	doc.setLoa(1627384);
	doc.setNocFromBuilder("hjwdjhjkhjkhjkh");
	doc.setSalarySlip("yes");
	doc.setAgreementToSale("Yes");
	doc.setCustomer(customer);

	DocRepo.insertDocument(doc);

	}
	}
	*/
	
	
	
	
	
	
	
	
	
}
	
	
	
	
	
	
     
