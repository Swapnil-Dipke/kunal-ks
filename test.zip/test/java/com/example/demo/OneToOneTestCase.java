package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.Transaction;
import com.example.demo.layer3.TransactionnRepositoryImpl;

public class OneToOneTestCase {

	@Autowired
	TransactionnRepositoryImpl transactionRepository;
	
	
	@Test
	void insertTransactionTest()
	{
		Transaction tran=new Transaction();
		tran.setTrannsactionId(5);
		tran.setTransactionMode("Online");
		tran.setTransactionAmount(100.0f);
		tran.setTransactionMode("succ");
		tran.setTransactionStatus("active");
//		transactionRepo.insertTransaction("Tran");
		transactionRepository.insertTransaction(tran);
		
		
//		
//		TransactionTable tran1=new TransactionTable();
//		tran1.setTrannsactionId(4);
//		tran1.setTransactionType("Online");
//		tran1.setTransactionAmount(12000.0f);
//		tran1.setTransactionMode("succ");
//		tran1.setTransactionStatus("active");
//		tranrepo.insertTransaction(tran1);
	}
	
}
