


/* package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.Booking;
import com.example.demo.layer3.BookingRepositoryImpl;

public class RawDemo {

	

	//------------------ Test for booking -------------------------
	@Autowired
	BookingRepositoryImpl bookingRepository;

	@Test
	void insertBookingTest() {
		Booking bkt = new Booking();
       //bkt.setBookingId(001);
		bkt.setEconomySeatsBooked(50);
		bkt.setBookingStatus("done");
		bkt.setBookingDate(LocalDate.of(2021, 11, 11));
		bkt.setBusinessSeatsBooked(23);
		bkt.setJourneyType("wonderlust");
		bkt.setTotalCost(20);
		bookingRepository.insertBooking(bkt);
		//   bookingRepository.insertBooking(bkt);  
	}

	@Test
	void SelectBookingTest() {

		Booking bkt = bookingRepository.selectBooking(80);

		System.out.println("Booking_Table  Booking_Id   is : " + bkt.getBookingId());
		System.out.println("Booking_Table Ac_Seats_Booked  : " + bkt.getEconomySeatsBooked());
		System.out.println("Booking_Table Booking_status  : " + bkt.getBusinessSeatsBooked());
		System.out.println("Booking_Table  Booking_Date is:" + bkt.getBookingDate());
		System.out.println("Booking_Table  Non_Ac_Seats is:" + bkt.getBookingStatus());
		System.out.println("Booking_Table  Return_Id is:" + bkt.getJourneyType());
		System.out.println("Booking_Table  Total_cost is:" + bkt.getTotalCost());
	}

	@Test
	void SelectAllBookingTest() {
//List <Booking> bktList=bookingRepository.findAll("Booking");

		List<Booking> bktList = bookingRepository.selectAllBooking();
		for (Booking bkt : bktList) {
			System.out.println("Booking_Table  Booking_Id   is : " + bkt.getBookingId());
			System.out.println("Booking_Table Ac_Seats_Booked  : " + bkt.getEconomySeatsBooked());
			System.out.println("Booking_Table Booking_status  : " + bkt.getBusinessSeatsBooked());
			System.out.println("Booking_Table  Booking_Date is:" + bkt.getBookingDate());
			System.out.println("Booking_Table  Non_Ac_Seats is:" + bkt.getBookingStatus());
			System.out.println("Booking_Table  Return_Id is:" + bkt.getJourneyType());
			System.out.println("Booking_Table  Total_cost is:" + bkt.getTotalCost());

		}
	}

	@Test
	public void updateBookingTest() {
		
		Booking bkt = new Booking();
		bkt.setBookingId(81);
		bkt.setEconomySeatsBooked(25);
		bkt.setBusinessSeatsBooked(30);
		bkt.setBookingDate(LocalDate.of(2021, 11, 11));
		bkt.setBookingStatus("no");
		bkt.setJourneyType("Bail");
		bkt.setTotalCost(1200);
		bookingRepository.updateBooking(bkt);
	}

     @Test
     void deleteBookingTest1(){
 Booking payee = new Booking();
 bookingRepository.deleteBooking(80);
 
}

    //------------------ Test for  -------------------------
 	@Autowired
 	BookingRepositoryImpl bookingRepository;

 	@Test
 	void insertBookingTest() {
 		Booking bkt = new Booking();
        //bkt.setBookingId(001);
 		bkt.setEconomySeatsBooked(50);
 		bkt.setBookingStatus("done");
 		bkt.setBookingDate(LocalDate.of(2021, 11, 11));
 		bkt.setBusinessSeatsBooked(23);
 		bkt.setJourneyType("wonderlust");
 		bkt.setTotalCost(20);
 		bookingRepository.insertBooking(bkt);
 		//   bookingRepository.insertBooking(bkt);  
 	}

 	@Test
 	void SelectBookingTest1() {

 		Booking bkt = bookingRepository.selectBooking(80);

 		System.out.println("Booking_Table  Booking_Id   is : " + bkt.getBookingId());
 		System.out.println("Booking_Table Ac_Seats_Booked  : " + bkt.getEconomySeatsBooked());
 		System.out.println("Booking_Table Booking_status  : " + bkt.getBusinessSeatsBooked());
 		System.out.println("Booking_Table  Booking_Date is:" + bkt.getBookingDate());
 		System.out.println("Booking_Table  Non_Ac_Seats is:" + bkt.getBookingStatus());
 		System.out.println("Booking_Table  Return_Id is:" + bkt.getJourneyType());
 		System.out.println("Booking_Table  Total_cost is:" + bkt.getTotalCost());
 	}

 	@Test
 	void SelectAllBookingTest() {
 //List <Booking> bktList=bookingRepository.findAll("Booking");

 		List<Booking> bktList = bookingRepository.selectAllBooking();
 		for (Booking bkt : bktList) {
 			System.out.println("Booking_Table  Booking_Id   is : " + bkt.getBookingId());
 			System.out.println("Booking_Table Ac_Seats_Booked  : " + bkt.getEconomySeatsBooked());
 			System.out.println("Booking_Table Booking_status  : " + bkt.getBusinessSeatsBooked());
 			System.out.println("Booking_Table  Booking_Date is:" + bkt.getBookingDate());
 			System.out.println("Booking_Table  Non_Ac_Seats is:" + bkt.getBookingStatus());
 			System.out.println("Booking_Table  Return_Id is:" + bkt.getJourneyType());
 			System.out.println("Booking_Table  Total_cost is:" + bkt.getTotalCost());

 		}
 	}

 	@Test
 	public void updateBookingTest() {
 		Booking bkt = new Booking();
 		bkt.setBookingId(81);
 		bkt.setEconomySeatsBooked(25);
 		bkt.setBusinessSeatsBooked(30);
 		bkt.setBookingDate(LocalDate.of(2021, 11, 11));
 		bkt.setBookingStatus("no");
 		bkt.setJourneyType("Bail");
 		bkt.setTotalCost(1200);
 		bookingRepository.updateBooking(bkt);
 	}

      @Test
      void deleteBookingTest1(){
  Booking payee = new Booking();
  bookingRepository.deleteBooking(80);
  
 }
     
	
}
*/
