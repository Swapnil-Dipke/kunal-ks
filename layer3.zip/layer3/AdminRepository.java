package com.example.demo.layer3;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Flight;

@Repository
public interface AdminRepository {

	 static void insertAdmin(Admin aobj) {
		// TODO Auto-generated method stub
		
	} //C
//	Admin selectAdmin(int aid); //R
//	List<Admin> selectAdmin(); //RA
//	
//	void updateAdmin(Admin aobj); //U
//	void deleteAdmin(int aid);
	
	void addFlight (Flight newFlight);
	void deleteFlight(int flightId);
	void updateFlight(Flight fobj); 

}
