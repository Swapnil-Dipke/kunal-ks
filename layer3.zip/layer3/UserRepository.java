package com.example.demo.layer3;

import java.util.List;

import com.example.demo.layer2.User;

public interface UserRepository {

	
	

	void insertUser(User uobj); 
	User selectUser(int uid); 
	List<User> selectAllUsers(); 
	void updateUser(User uobj); 
	void deleteUser(int uid);

	
	
	
	
	
}
