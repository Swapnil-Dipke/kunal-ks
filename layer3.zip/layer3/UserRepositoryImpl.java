package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.User;

public class UserRepositoryImpl extends BaseRepository implements UserRepository {


	@Transactional
	public void insertUser(User uobj) {
		super.persist(uobj);
	}

	@Override
	public User selectUser(int uid) {
		// TODO Auto-generated method stub
		User user=super.find(User.class, uid);
		return user;
	}

	@Override
	public List<User> selectAllUsers() {
		List<User> usersList=new ArrayList<User>();
		return super.findAll("User");
	}

	@Transactional
	public void updateUser(User uobj) {
		super.merge(uobj);
	}

	@Transactional
	public void deleteUser(int uid) {
		super.remove(User.class, uid);
	}

	
	
	
	
}
