package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Cancellation;

public class CancellationrepositoryImpl extends BaseRepository  implements CancellationRepository {

	

//	public CancellationRepoImpl() {
//		super();
//		System.out.println("CancellationRepoImple.............");
//	}

	@Transactional
	public void insertCancellation(Cancellation cobj)
	{
		super.persist(cobj);
		System.out.println("Cancellation inserted:");
	}

	@Override
	public Cancellation selectCancellation(int cid) {
		Cancellation cancellation=super.find(Cancellation.class, cid);
		return cancellation;
	}

	@Override
	public List<Cancellation> selectAllCancellation() {
		List<Cancellation> cancellationsList=new ArrayList<Cancellation>();
		return super.findAll("Cancellation");
	}

	@Transactional
	public void updateCancellation(Cancellation cobj) {
		super.merge(cobj);
	}

	@Override
	public void deleteCancellation(int cid) {
		super.remove(Cancellation.class,cid );
	}
	
	
	
	
	
	
	
	
	
}
