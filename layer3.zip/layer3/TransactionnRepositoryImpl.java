package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Transaction;

@Repository
public class TransactionnRepositoryImpl extends BaseRepository implements TransactionRepository{

	
	
	

	@Transactional
	public void insertTransaction(Transaction tobj) {
		super.persist(tobj);
	}

	@Override
	public Transaction selectTransaction(int tid) {
		Transaction transaction=super.find(Transaction.class, tid);
	
		return transaction;
	}

	@Override
	public List<Transaction> selectAllTransaction() {
		List<Transaction> list=new ArrayList<Transaction>();
		return super.findAll("Transaction");
	}

	@Transactional
	public void updateTransaction(Transaction dobj) {
		super.merge(dobj);
	}

	@Override
	public void deleteTransaction(int tid) {
		super.remove(Transaction.class, tid);
	}

	
	
}
