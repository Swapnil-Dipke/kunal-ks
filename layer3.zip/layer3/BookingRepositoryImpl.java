package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Booking;

@Repository
public class BookingRepositoryImpl extends BaseRepository implements BookingRepository {

	@Transactional
	public void insertBooking(Booking bobj) {
		super.persist(bobj);
	}

	@Transactional
	public Booking selectBooking(int bid) 
	{
		Booking booking=super.find(Booking.class, bid);
		return booking;
	}

	@Override
	public List<Booking> selectBooking() {
		List<Booking> bookingList=super.findAll("Booking");
		return bookingList;
	}

	
	@Override
	public void updateBookings(Booking bobj) {
		// TODO Auto-generated method stub
		super.merge(bobj);
	}

	@Override
	public void deleteBookings(int bid) {
		// TODO Auto-generated method stub
		super.remove(Booking.class, bid);
	}

	
	
	
}
