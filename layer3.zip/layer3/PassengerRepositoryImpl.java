package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import com.example.demo.layer2.Passenger;

public class PassengerRepositoryImpl extends BaseRepository implements PassengerRepository {

	

	@Transactional
	public void insertPassenger(Passenger pobj) {
		super.persist(pobj);
		
	}

	@Override
	public Passenger selectPassenger(int pid) {
		Passenger passenger=super.find(Passenger.class, pid);
		return passenger;
	}

	@Override
	public List<Passenger> selectAllPassenger() {
		List<Passenger> list=super.findAll("Passenger");
		return list;
	}

	@Transactional
	public void updatePassenger(Passenger pobj) {
		super.merge(pobj);
		
	}

	@Transactional
	public void deletePassenger(int pid) {
		super.remove(Passenger.class, pid);	
	}
	
	
	
	
	
	
	
	
}
