package com.example.demo.layer3;

import java.util.List;

import com.example.demo.layer2.Passenger;

public interface PassengerRepository {

	

	void insertPassenger(Passenger pobj); 
	Passenger selectPassenger(int pid); 
	List<Passenger> selectAllPassenger(); 
	void updatePassenger(Passenger pobj); 
	void deletePassenger(int pid); 
	
	
	
}
