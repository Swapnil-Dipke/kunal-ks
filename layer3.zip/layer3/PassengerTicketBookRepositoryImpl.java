package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Booking;
import com.example.demo.layer2.PassengerTicketBook;

@Repository
public class PassengerTicketBookRepositoryImpl extends BaseRepository implements PassengerTicketBookRepository{

	@Transactional
	public void insertPassengerTicketBook(PassengerTicketBook pobj) {
		super.persist(pobj); // invoking the dummy persist of the super class
		System.out.println(" insert passenger ticket book table inserted...");
		
	}

	@Override
	public Booking selectPassengerTicketBook(int passengerTransactionId) {

		System.out.println("Passenger ticket book table RepositoryImpl : selecting passenger ticket book table ");
		Booking pticketBook = super.find(Booking.class, passengerTransactionId);

		return pticketBook;

	}

	@Override
	public List selectAllPassengerTicketBook() {
		List<PassengerTicketBook> bktList = new ArrayList<PassengerTicketBook>();
		System.out.println("PassengerTicketBook RepositoryImpl: select All PassengerTicketBook ");
		return super.findAll("PassengerTicketBook");
	}
	@Transactional
	public void updatePassengerTicketBook(Booking pobj) {
		System.out.println(" Passenger ticket book repositoryImpl: Updating Passenger ticket book table...");
		super.merge(pobj);

	}

	@Transactional
	public void deletePassengerTicketBook(int passengerTransactionId) {
		System.out.println(" Passenger ticket book RepositoryImpl: Deleting rom passenger ticket book ");
		super.remove(PassengerTicketBook.class, passengerTransactionId);
	}

	
	
}
