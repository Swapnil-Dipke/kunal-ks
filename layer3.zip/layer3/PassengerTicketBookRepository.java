package com.example.demo.layer3;

import java.util.List;

import com.example.demo.layer2.Booking;
import com.example.demo.layer2.PassengerTicketBook;

public interface PassengerTicketBookRepository {
	

	void insertPassengerTicketBook(PassengerTicketBook pobj);

	Booking selectPassengerTicketBook(int passengerTransactionId);
	List selectAllPassengerTicketBook();


	void updatePassengerTicketBook(Booking pobj);
	void deletePassengerTicketBook(int passengerTransactionId);


}
