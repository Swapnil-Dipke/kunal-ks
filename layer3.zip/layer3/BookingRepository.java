package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Booking;





@Repository
public interface BookingRepository {
void insertBooking(Booking bobj); //C
	
	Booking selectBooking(int bid); //R
	List<Booking> selectBooking(); //RA
	
	void updateBookings(Booking bobj); //U
	void deleteBookings(int bid);
	
}
