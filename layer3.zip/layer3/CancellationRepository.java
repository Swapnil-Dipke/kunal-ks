package com.example.demo.layer3;

import java.util.List;

import com.example.demo.layer2.Cancellation;

public interface CancellationRepository {

	
	void insertCancellation(Cancellation cobj); //C
	
	Cancellation selectCancellation(int cid); //R
	List<Cancellation> selectAllCancellation(); //RA
	
	void updateCancellation(Cancellation cobj); //U
	void deleteCancellation(int cid); //D
	
	
	
	
}
