package com.example.demo.layer2;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="Passenger_Ticket_Book")
public class PassengerTicketBook 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Passenger_Transaction_ID")
	private String passengerTransactionId;
	
	
	@ManyToOne
	@JoinColumn(name="Booking_Id")
	private BookingTable bookingTable;
	
	
	
	@ManyToOne
	@JoinColumn(name="Passenger_Id")
	private PassengerTable passengerId;
	
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "passengerTicketBook") //one Department has Many Employees
		private Set<seatTable> seatTableSet = new HashSet<seatTable>();
		
		
	@ManyToOne
	@JoinColumn(name="Flight_ID")
	private String flightId;



	
	
	
	public PassengerTicketBook(String passengerTransactionId, BookingTable bookingId, PassengerTable passengerId,
			Set<seatTable> seatTableSet, String flightId) {
		super();
		this.passengerTransactionId = passengerTransactionId;
		BookingId = bookingId;
		this.passengerId = passengerId;
		this.seatTableSet = seatTableSet;
		this.flightId = flightId;
	}


	//--------- GETTER AND SETTER METHOD --------------------
	
	

	public String getPassengerTransactionId() {
		return passengerTransactionId;
	}




	public void setPassengerTransactionId(String passengerTransactionId) {
		this.passengerTransactionId = passengerTransactionId;
	}




	public BookingTable getBookingId() {
		return BookingId;
	}




	public void setBookingId(BookingTable bookingId) {
		BookingId = bookingId;
	}




	public PassengerTable getPassengerId() {
		return passengerId;
	}




	public void setPassengerId(PassengerTable passengerId) {
		this.passengerId = passengerId;
	}




	public Set<seatTable> getSeatTableSet() {
		return seatTableSet;
	}




	public void setSeatTableSet(Set<seatTable> seatTableSet) {
		this.seatTableSet = seatTableSet;
	}




	public String getFlightId() {
		return flightId;
	}




	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}




	

	
	
	


	
	
	
	
}
