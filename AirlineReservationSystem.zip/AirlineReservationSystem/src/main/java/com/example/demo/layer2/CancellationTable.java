package com.example.demo.layer2;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity  
@Table(name="Cancellation")
public class CancellationTable
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Cancellation_ID")
	private int cancellationId;
	
	@Column(name="Cancellation_Date")
	private LocalDate cancellationDate;
	
	@Column(name="Cancellation_Reason")
	private String cancellationReason;
	
	@Column(name="Cancellation_Status")
	private String cancellationStatus;
	
	@Column(name="Refund_Amount")
	private double refundAmount;
	
	@Column(name="Transaction_Id")
	private String Transaction_Id;
	
	@OneToMany(cascade = CascadeType.ALL,  mappedBy = "") //one Department has Many Employees
	private Set<BookingTable> bookingTableSet = new HashSet<BookingTable>();
	
	
	
	
	//-------------- GETTER AND SETTER--------------------

	public int getCancellationId() {
		return cancellationId;
	}

	public void setCancellationId(int cancellationId) {
		this.cancellationId = cancellationId;
	}

	public LocalDate getCancellationDate() {
		return cancellationDate;
	}

	public void setCancellationDate(LocalDate cancellationDate) {
		this.cancellationDate = cancellationDate;
	}

	public String getCancellationReason() {
		return cancellationReason;
	}

	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}

	public String getCancellationStatus() {
		return cancellationStatus;
	}

	public void setCancellationStatus(String cancellationStatus) {
		this.cancellationStatus = cancellationStatus;
	}

	public double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getTransaction_Id() {
		return Transaction_Id;
	}

	public void setTransaction_Id(String transaction_Id) {
		Transaction_Id = transaction_Id;
	}

	@Override
	public String toString() {
		return "CancellationTable [cancellationId=" + cancellationId + ", cancellationDate=" + cancellationDate
				+ ", cancellationReason=" + cancellationReason + ", cancellationStatus=" + cancellationStatus
				+ ", refundAmount=" + refundAmount + ", Transaction_Id=" + Transaction_Id + "]";
	}
	
	
}
